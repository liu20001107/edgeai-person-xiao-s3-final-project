@echo off
setlocal

if "%~1"=="" (
  echo Usage: flash_model.bat COM_PORT
  echo Example: flash_model.bat COM3
  exit /b 2
)

set "PORT=%~1"
set "ROOT=%~dp0.."
set "MODEL=%ROOT%\models\person_local_focus100_models_partition.bin"

if not exist "%MODEL%" (
  echo Model partition not found:
  echo %MODEL%
  exit /b 3
)

if exist "C:\Espressif\idf_cmd_init.bat" (
  call C:\Espressif\idf_cmd_init.bat esp-idf-b6a194b5a91072dd391c1b6ce749efc8
  set "PATH=C:\Espressif\python_env\idf5.3_py3.11_env\Scripts;C:\Espressif\frameworks\esp-idf-v5.3.5\tools;%PATH%"
)

python -m esptool --chip esp32s3 --port "%PORT%" -b 460800 --before default_reset --after hard_reset write_flash --flash_mode dio --flash_freq 80m --flash_size detect 0x400000 "%MODEL%"
exit /b %ERRORLEVEL%
