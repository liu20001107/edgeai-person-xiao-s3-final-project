_base_ = ["configs/yolov5/yolov5_tiny_1xb16_300e_coco.py"]

num_classes = 1
data_root = "datasets/person_grounding_dino_local_focus/"
train_ann = "train/_annotations.coco.json"
train_data = "train/"
val_ann = "valid/_annotations.coco.json"
val_data = "valid/"

height = 192
width = 192
imgsz = (width, height)

batch = 4
workers = 0
val_batch = 4
val_workers = 0
persistent_workers = False

epochs = 100
val_interval = 10
save_interval = 10
close_mosaic_epochs = 10
work_dir = "work_dirs/sscma_person_grounding_dino_local_focus_train100_config"

model = dict(
    bbox_head=dict(
        head_module=dict(num_classes=num_classes),
    )
)

train_dataloader = dict(
    batch_size=batch,
    num_workers=workers,
    persistent_workers=False,
    dataset=dict(
        data_root=data_root,
        ann_file=train_ann,
        data_prefix=dict(img=train_data),
    ),
)

val_dataloader = dict(
    batch_size=val_batch,
    num_workers=val_workers,
    persistent_workers=False,
    dataset=dict(
        data_root=data_root,
        ann_file=val_ann,
        data_prefix=dict(img=val_data),
    ),
)

test_dataloader = val_dataloader
val_evaluator = dict(ann_file=data_root + val_ann)
test_evaluator = val_evaluator

train_cfg = dict(max_epochs=epochs, val_interval=val_interval)
default_hooks = dict(
    logger=dict(interval=20),
    checkpoint=dict(interval=save_interval, save_best=None, max_keep_ckpts=3),
)
