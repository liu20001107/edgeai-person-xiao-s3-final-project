@echo off
setlocal

if "%~1"=="" (
  echo Usage: monitor.bat COM_PORT
  echo Example: monitor.bat COM3
  exit /b 2
)

set "PORT=%~1"
python -m serial.tools.miniterm "%PORT%" 115200
