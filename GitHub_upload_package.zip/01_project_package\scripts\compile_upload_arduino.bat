@echo off
setlocal

if "%~1"=="" (
  echo Usage: compile_upload_arduino.bat COM_PORT
  echo Example: compile_upload_arduino.bat COM3
  exit /b 2
)

set "PORT=%~1"
set "ROOT=%~dp0.."
set "SKETCH=%ROOT%\arduino\sscma_person_arduino"
set "ARDUINO_CLI=C:\Program Files\Arduino IDE\resources\app\lib\backend\resources\arduino-cli.exe"
set "FQBN=esp32:esp32:XIAO_ESP32S3:USBMode=hwcdc,CDCOnBoot=default,MSCOnBoot=default,DFUOnBoot=default,UploadMode=default,CPUFreq=240,FlashMode=qio,FlashSize=8M,PartitionScheme=max_app_8MB,DebugLevel=none,PSRAM=opi,LoopCore=1,EventsCore=1,EraseFlash=none,JTAGAdapter=default"

if not exist "%ARDUINO_CLI%" (
  echo arduino-cli not found. Please install Arduino IDE 2.x first.
  exit /b 3
)

"%ARDUINO_CLI%" compile --fqbn "%FQBN%" "%SKETCH%"
if errorlevel 1 exit /b %ERRORLEVEL%

"%ARDUINO_CLI%" upload -p "%PORT%" --fqbn "%FQBN%" "%SKETCH%"
exit /b %ERRORLEVEL%
