Edge AI final project contents

Folder name requested by user:
C:\Users\Rui\Desktop\NTUST\edge ai\finnal project

Suggested use:
- Upload 01_project_package to GitHub.
- Use docs/HackMD.md or the online HackMD page for the report.
- Use arduino/sscma_person_arduino/sscma_person_arduino.ino for the ESP32S3 sketch.
- Use models/person_local_focus100_models_partition.bin as the final model partition.
- Use pc_viewer/serial_person_viewer.py to display the ESP32 camera image over USB without Wi-Fi.

Folder map:

01_project_package
- Clean deliverable package.
- Includes Arduino sketch, final model files, training configs, scripts, HackMD docs, and USB VS Code viewer.

02_dataset_grounding_dino_person
- Person dataset preview and labels generated with GroundingDINO.
- Includes preview images with detection boxes and summary/label files.

03_dataset_no_person_background
- No-person room/background images.
- Useful for explaining false positives and future negative-sample training.

04_training_outputs_and_models
- Model exports, flashed partition binaries, Arduino sketches, and training/flash output logs from this project.

05_training_logs
- Selected training/export logs and status files.
- Does not include large dependency folders or installer archives.

06_report_template
- Course PPT/report template copied from Downloads.

Important final settings:
- Final model: local_focus100
- ESP32 model flash address: 0x400000
- Arduino trigger threshold: 0.75
- Minimum box area: 0.35
- LED hold time: 10 seconds
- USB viewer baud rate: 921600
