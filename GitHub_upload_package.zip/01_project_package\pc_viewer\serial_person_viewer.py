import io
import json
import queue
import struct
import sys
import threading
import time
import tkinter as tk
from tkinter import ttk

try:
    import serial
except ImportError:
    print("Missing pyserial. Run: py -m pip install pyserial pillow")
    raise

try:
    from PIL import Image, ImageTk
except ImportError:
    print("Missing Pillow. Run: py -m pip install pyserial pillow")
    raise


MAGIC = b"XIAOAI1\n"
DEFAULT_PORT = "COM3"
DEFAULT_BAUD = 921600
MAX_JSON_LEN = 16 * 1024
MAX_JPG_LEN = 512 * 1024


def read_exact(port, size):
    data = bytearray()
    while len(data) < size:
        chunk = port.read(size - len(data))
        if not chunk:
            raise TimeoutError("serial read timeout")
        data.extend(chunk)
    return bytes(data)


def wait_for_magic(port):
    window = bytearray()
    while True:
        b = port.read(1)
        if not b:
            raise TimeoutError("waiting for frame")
        window.extend(b)
        if len(window) > len(MAGIC):
            del window[0]
        if bytes(window) == MAGIC:
            return


def serial_reader(port_name, baud, out_queue, stop_event):
    while not stop_event.is_set():
        try:
            with serial.Serial(port_name, baud, timeout=2) as port:
                time.sleep(1.0)
                port.reset_input_buffer()
                out_queue.put(("status", f"Connected: {port_name} @ {baud}"))
                while not stop_event.is_set():
                    wait_for_magic(port)
                    json_len, jpg_len = struct.unpack("<II", read_exact(port, 8))
                    if json_len > MAX_JSON_LEN or jpg_len > MAX_JPG_LEN:
                        out_queue.put(("status", "Bad frame size, resyncing..."))
                        continue
                    meta = json.loads(read_exact(port, json_len).decode("utf-8"))
                    jpg = read_exact(port, jpg_len)
                    out_queue.put(("frame", meta, jpg))
        except serial.SerialException as exc:
            out_queue.put(("status", f"Serial error: {exc}"))
            time.sleep(2)
        except Exception as exc:
            out_queue.put(("status", f"Waiting for data: {exc}"))
            time.sleep(0.2)


class PersonViewer:
    def __init__(self, root, port_name, baud):
        self.root = root
        self.root.title("XIAO ESP32S3 Person Detection - USB Viewer")
        self.root.geometry("820x620")
        self.root.minsize(520, 420)

        self.queue = queue.Queue(maxsize=4)
        self.stop_event = threading.Event()
        self.photo = None

        self.status_var = tk.StringVar(value="Opening serial port...")
        self.detail_var = tk.StringVar(value=f"Port: {port_name} | Baud: {baud}")

        header = ttk.Frame(root, padding=10)
        header.pack(fill="x")
        self.status_label = ttk.Label(header, textvariable=self.status_var, font=("Segoe UI", 16, "bold"))
        self.status_label.pack(anchor="w")
        ttk.Label(header, textvariable=self.detail_var, font=("Segoe UI", 10)).pack(anchor="w", pady=(3, 0))

        self.image_label = ttk.Label(root, anchor="center")
        self.image_label.pack(fill="both", expand=True, padx=10, pady=10)

        self.reader = threading.Thread(
            target=serial_reader,
            args=(port_name, baud, self.queue, self.stop_event),
            daemon=True,
        )
        self.reader.start()
        self.root.protocol("WM_DELETE_WINDOW", self.close)
        self.root.after(50, self.poll_queue)

    def show_frame(self, meta, jpg):
        image = Image.open(io.BytesIO(jpg)).convert("RGB")
        max_w = max(self.image_label.winfo_width() - 20, 320)
        max_h = max(self.image_label.winfo_height() - 20, 240)
        image.thumbnail((max_w, max_h), Image.Resampling.LANCZOS)
        self.photo = ImageTk.PhotoImage(image)
        self.image_label.configure(image=self.photo)

        detected = bool(meta.get("detected", False))
        label = "PERSON DETECTED" if detected else "NO PERSON"
        best = float(meta.get("best", 0.0))
        raw = float(meta.get("raw", 0.0))
        light = meta.get("light", "OFF")
        valid = int(meta.get("valid", 0))
        self.status_var.set(f"{label} | best={best:.3f} raw={raw:.3f} valid={valid} light={light}")
        self.status_label.configure(foreground=("#138a36" if detected else "#b3261e"))

    def poll_queue(self):
        try:
            while True:
                item = self.queue.get_nowait()
                if item[0] == "frame":
                    self.show_frame(item[1], item[2])
                elif item[0] == "status":
                    self.detail_var.set(item[1])
        except queue.Empty:
            pass
        self.root.after(50, self.poll_queue)

    def close(self):
        self.stop_event.set()
        self.root.destroy()


def main():
    port_name = sys.argv[1] if len(sys.argv) >= 2 else DEFAULT_PORT
    baud = int(sys.argv[2]) if len(sys.argv) >= 3 else DEFAULT_BAUD
    root = tk.Tk()
    PersonViewer(root, port_name, baud)
    root.mainloop()


if __name__ == "__main__":
    main()
