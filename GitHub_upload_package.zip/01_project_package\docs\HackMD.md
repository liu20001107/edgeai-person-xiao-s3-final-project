# Edge AI 期末專題：XIAO ESP32S3 即時人員偵測

## 1. 專題簡介

本專題使用 Seeed Studio XIAO ESP32S3 Sense 製作一個可在板子端獨立執行的人員偵測、智慧照明與即時影像顯示系統。相機影像由 XIAO ESP32S3 Sense 擷取，模型以 int8 TFLite 格式燒錄在 ESP32S3 flash 中，Arduino 程式透過 SSCMA Micro Core 呼叫模型推論。偵測到人時，板子上方內建 LED 會亮起；最後一次偵測到人後維持亮燈 10 秒，如果 10 秒內再次偵測到人就重新計時。板子也會開啟 Wi-Fi AP，使用者可用瀏覽器看到 ESP32 拍到的畫面與偵測框。

專題目標：

- 在邊緣裝置上執行 AI 推論。
- 不依賴雲端與電腦端推論。
- 能辨識畫面中是否有人。
- 偵測到人時自動開燈，無人 10 秒後自動關燈。
- 使用瀏覽器即時顯示 ESP32 相機畫面與偵測框。
- 可交付給只有板子的使用者使用。

使用硬體：

- Seeed Studio XIAO ESP32S3 Sense
- 內建 camera module
- USB-C 連接線

使用軟體：

- Arduino IDE 2.x
- ESP32 Arduino board package
- Seeed SSCMA Micro Core library
- Seeed Studio ModelAssistant / SSCMA
- Python 3.10
- PyTorch + CUDA
- TensorFlow Lite
- esptool

## 2. GitHub 專案結構

```text
edgeai-person-xiao-s3/
├─ arduino/
│  └─ sscma_person_arduino/
│     └─ sscma_person_arduino.ino
├─ models/
│  ├─ person_local_focus100_int8.tflite
│  └─ person_local_focus100_models_partition.bin
├─ scripts/
│  ├─ compile_upload_arduino.bat
│  ├─ flash_model.bat
│  └─ monitor.bat
├─ training/
│  ├─ sscma_person_grounding_dino_local_focus_train100_config.py
│  └─ sscma_person_grounding_dino_local_bg_focus_finetune50_config.py
└─ docs/
   └─ HackMD.md
```

GitHub 可放內容：

- 完整 Arduino 程式。
- 已匯出的模型。
- 可直接燒錄的 model partition。
- 訓練 config。
- Windows 批次腳本。
- 本 HackMD 說明文件。

建議不要上傳內容：

- 原始大型資料集。
- Python virtual environment。
- 暫存 log。
- 個人本機絕對路徑。

## 3. 完整 Arduino 程式功能

Arduino sketch 路徑：

```text
arduino/sscma_person_arduino/sscma_person_arduino.ino
```

程式流程：

1. 初始化 Serial。
2. 初始化 XIAO ESP32S3 Sense camera。
3. 初始化 SSCMA Micro Core。
4. 從 flash `0x400000` 載入模型。
5. 每次 loop 擷取一張影像。
6. 呼叫 `ai.invoke()` 執行模型推論。
7. 讀取模型輸出的 bounding boxes。
8. 依照 score 與 bbox area 過濾假陽性。
9. 輸出 `PERSON DETECTED` 或 `NO PERSON`。
10. 偵測到人時打開內建 LED，超過 10 秒未偵測到人則關閉內建 LED。
11. 將目前 frame 畫上偵測框後轉成 JPEG，提供給瀏覽器網頁顯示。

重要參數：

```cpp
static constexpr float kTriggerThreshold = 0.75f;
static constexpr float kMinBoxArea = 0.35f;
static constexpr uint32_t kDetectHoldMs = 800;
static constexpr uint8_t kRequiredHits = 1;
static constexpr uint32_t kLightHoldMs = 10000;
static constexpr int kLightPin = LED_BUILTIN;
static constexpr uint8_t kLightOnLevel = LOW;
static constexpr uint8_t kLightOffLevel = HIGH;

static SSCMAMicroCore::InvokeConfig invoke_config = {
    .top_k = 10,
    .score_threshold = 0.30f,
    .nms_threshold = 0.45f,
};
```

參數說明：

| 參數 | 意義 |
|---|---|
| `score_threshold` | 模型輸出候選框的最低分數 |
| `top_k` | 最多保留幾個候選框 |
| `nms_threshold` | 重疊框合併門檻 |
| `kTriggerThreshold` | 判定有人所需的最低分數 |
| `kMinBoxArea` | bbox 佔畫面比例，太小視為誤判 |
| `kDetectHoldMs` | 偵測狀態保留時間 |
| `kLightHoldMs` | 燈亮保持時間，10000 ms 等於 10 秒 |
| `kLightPin` | 控制燈的腳位，預設使用板子內建 LED |

智慧照明邏輯：

```text
偵測到人 -> 內建 LED 亮
持續偵測到人 -> 每次都重設 10 秒倒數
10 秒內沒再偵測到人 -> 內建 LED 熄滅
```

本版本使用板子上方內建 LED，不需要外接電路。XIAO ESP32S3 的內建 LED 在 Arduino variant 中定義為 `LED_BUILTIN = GPIO21`，且低電位亮，所以程式使用 `LOW` 表示亮燈、`HIGH` 表示關燈。

即時影像顯示：

```text
SSID: XIAO-Person-Cam
Password: 12345678
URL: http://192.168.4.1
```

網頁功能：

- 顯示 ESP32 拍到的最新畫面。
- 紅框代表通過條件的 person 框。
- 黃框代表模型有輸出但被面積條件過濾的小框。
- 頁面上方顯示 `PERSON DETECTED / NO PERSON`、best score、raw score、LED 狀態。

影像顯示實作方式：

```text
RGB565 camera frame
-> 複製一份 frame buffer
-> 根據模型 bbox 畫紅框或黃框
-> fmt2jpg() 轉成 JPEG
-> WebServer 提供 /jpg
-> 瀏覽器定時刷新圖片
```

由於模型推論約 0.7 秒一次，因此網頁更新速度約 1 FPS，適合期末展示與智慧居家狀態監控。

目前採用「模型高分 + Arduino 後處理」策略。原因是加入太多空房間負樣本後，模型在板子上的 person 分數被壓得太低，因此正式版使用較容易偵測人的 `local_focus100` 模型，再用 bbox area 過濾空房間誤判。

## 4. 資料集製作

資料來源分成三類：

1. Kaggle / 公開 person 場景圖片。
2. 實際使用 XIAO ESP32S3 Sense 或同角度拍攝的本地房間 person 圖片。
3. 本地房間無人背景圖。

實際使用過的本地背景資料：

```text
C:\Users\Rui\Documents\Codex\2026-05-28\new-chat\dataset_train\background
```

共有 99 張房間無人 `.bmp` 圖片。

實際 person 圖片：

```text
C:\Users\Rui\Documents\Codex\2026-05-28\new-chat\dataset_all\person
```

標註方式：

- 使用 GroundingDINO 產生 person bounding boxes。
- 將標註轉為 COCO 格式。
- 圖片 resize 成模型訓練可用大小。

正式模型資料集：

```text
datasets/person_grounding_dino_local_focus
```

訓練資料統計：

| split | image records | annotations |
|---|---:|---:|
| train | 6612 | 10337 |
| valid | 536 | 977 |
| test | 538 | 937 |

曾測試加入背景負樣本：

```text
datasets/person_grounding_dino_local_bg_focus
```

加入方式：

- train 加入 2370 張房間空景負樣本。
- valid 加入 10 張房間空景。
- test 加入 10 張房間空景。
- 空景圖片保留在 COCO images 中，但沒有 annotations。

結果：

- validation AP@0.50 約 0.697~0.700。
- 但 ESP32S3 實機分數太低，person score 約 0.016~0.031。
- 因此沒有採用為正式版。

### 4.1 訓練集照片範例

資料集來源包含 Kaggle 人員影像、GroundingDINO 自動標註後轉成 COCO 格式的人員 bounding box，以及後續補拍的 XIAO ESP32S3 Sense 實際使用場景照片。實際拍攝照片能讓模型更接近最後部署環境，例如房間、桌面、椅子、牆面與人物坐姿。

**實際用 XIAO ESP32S3 Sense 拍攝的人員照片**

![實際拍攝人員照片](assets/local_person_actual_preview_hackmd.jpg)

**local_focus 訓練集的人員標註預覽**

![local_focus 訓練集](assets/local_focus_train_preview_hackmd.jpg)

**房間空景與無人背景資料**

![房間背景資料](assets/local_room_background_train_preview_hackmd.jpg)

**train50 版本的人員偵測標註預覽**

![train50 訓練資料](assets/train50_person_occupancy_preview_hackmd.jpg)

### 4.2 訓練版本比較

本專題中測試過數個模型版本：

| 版本 | 訓練內容 | 實機結果 | 是否採用 |
|---|---|---|---|
| train50 | 基礎 person 資料訓練 50 epoch | 可以偵測到人，但穩定度不足 | 否 |
| clean100 | 清理後 person 資料訓練 100 epoch | 分數比 train50 穩定 | 否 |
| local_focus100 | 加入實際場景 person 照片後訓練 100 epoch | 實機 person score 約 0.7~0.9 | 是 |
| local_bg_focus50 | 在 local_focus 上加入房間無人背景再 fine-tune 50 epoch | 空景誤判降低，但人物分數降到 0.016~0.031 | 否 |

最後採用 `local_focus100`，因為它在實際拍攝人物時分數最高，較符合智慧居家「有人就亮燈」的需求。為了降低小框誤判，Arduino 端再加上 `score + bbox area` 的雙重條件。

## 5. 模型訓練流程

使用 Seeed Studio ModelAssistant / SSCMA。

正式訓練 config：

```text
training/sscma_person_grounding_dino_local_focus_train100_config.py
```

主要設定：

```python
_base_ = ["configs/yolov5/yolov5_tiny_1xb16_300e_coco.py"]

num_classes = 1
data_root = "datasets/person_grounding_dino_local_focus/"
train_ann = "train/_annotations.coco.json"
train_data = "train/"
val_ann = "valid/_annotations.coco.json"
val_data = "valid/"

height = 192
width = 192
batch = 4
workers = 0
epochs = 100
val_interval = 10
save_interval = 10
work_dir = "work_dirs/sscma_person_grounding_dino_local_focus_train100_config"
```

訓練命令：

```bash
cd Seeed-Studio-ModelAssistant-104c4a5
python -u tools/train.py sscma_person_grounding_dino_local_focus_train100_config.py
```

使用的 COCO 標註檔：

```text
datasets/person_grounding_dino_local_focus/train/_annotations.coco.json
datasets/person_grounding_dino_local_focus/valid/_annotations.coco.json
```

整體訓練與部署流程：

```mermaid
flowchart LR
    A[收集 person / background 圖片] --> B[GroundingDINO 自動標註 person]
    B --> C[人工檢查與整理標註]
    C --> D[轉成 COCO dataset]
    D --> E[YOLOv5 tiny 訓練 100 epoch]
    E --> F[匯出 int8 TFLite]
    F --> G[修正 concat quantization scale]
    G --> H[打包 4MB model partition]
    H --> I[燒錄到 ESP32S3 0x400000]
```

本機訓練環境：

- GPU: NVIDIA GeForce RTX 3070 Ti
- PyTorch: 2.0.1 + CUDA 11.8
- Python: 3.10

訓練完成 checkpoint：

```text
work_dirs/sscma_person_grounding_dino_local_focus_train100_config/epoch_100.pth
```

驗證結果：

```text
AP@0.50 約 0.732
```

## 6. 匯出 TFLite

匯出 int8 與 float32 TFLite：

```bash
python -u tools/export.py \
  sscma_person_grounding_dino_local_focus_train100_config.py \
  work_dirs/sscma_person_grounding_dino_local_focus_train100_config/epoch_100.pth \
  --targets tflite \
  --precisions int8 float32 \
  --output_stem xiao_person_grounding_dino_local_focus100 \
  --work_dir work_dirs/sscma_person_grounding_dino_local_focus_train100_config \
  --device cpu
```

輸出：

```text
xiao_person_grounding_dino_local_focus100_int8.tflite
xiao_person_grounding_dino_local_focus100_float32.tflite
```

## 7. TFLite 修正

原始 int8 TFLite 在部分 `CONCATENATION` op 的 input quantization scale 不一致：

```text
部分 input scale = 0.390625
output scale = 1.534345 或相近值
```

這會造成 ESP32S3 / TFLite Micro 執行時不穩，因此使用 TensorFlow Lite schema 將 concat input scale 修成 output scale。

正式 patched 模型：

```text
models/person_local_focus100_int8.tflite
```

確認方式：

- patch 後 TensorFlow Lite Interpreter 可正常 `allocate_tensors()`。
- 實機推論可正常執行。

## 8. 包成 ESP32S3 model partition

模型燒錄位置為：

```text
0x400000
```

將 `.tflite` 補成 4MB partition：

```python
from pathlib import Path

src = Path("person_local_focus100_int8.tflite")
out = Path("person_local_focus100_models_partition.bin")
size = 4 * 1024 * 1024
blob = src.read_bytes()
out.write_bytes(blob + bytes([0xFF]) * (size - len(blob)))
```

正式 model partition：

```text
models/person_local_focus100_models_partition.bin
```

## 9. 燒錄流程

### 上傳 Arduino 程式

```bat
scripts\compile_upload_arduino.bat COM3
```

Arduino IDE board 設定：

```text
Board: XIAO_ESP32S3
USB CDC On Boot: Enabled
CPU Frequency: 240MHz
Flash Mode: QIO 80MHz
Flash Size: 8MB
Partition Scheme: max_app_8MB
PSRAM: OPI PSRAM
USB Mode: Hardware CDC and JTAG
Upload Mode: UART0 / Hardware CDC
```

### 燒錄模型

```bat
scripts\flash_model.bat COM3
```

內部 esptool 命令：

```bash
python -m esptool \
  --chip esp32s3 \
  --port COM3 \
  -b 460800 \
  --before default_reset \
  --after hard_reset \
  write_flash \
  --flash_mode dio \
  --flash_freq 80m \
  --flash_size detect \
  0x400000 models/person_local_focus100_models_partition.bin
```

燒錄成功訊息：

```text
Hash of data verified.
Hard resetting via RTS pin...
```

## 10. 客戶使用說明

如果客戶只有已燒錄好的板子：

1. 將 XIAO ESP32S3 Sense 接上 USB。
2. 打開 Arduino IDE 或任意 Serial Monitor。
3. 選擇對應 COM port。
4. 設定 baud rate 為 `115200`。
5. 等待輸出 `Ready.`。
6. 將人放到相機畫面中測試。
7. 看板子上方內建 LED，偵測到人會亮，無人 10 秒後熄滅。
8. 連上 Wi-Fi `XIAO-Person-Cam`，密碼 `12345678`。
9. 用瀏覽器開 `http://192.168.4.1`，可以看到即時畫面與偵測框。

輸出範例：

```text
SSCMA person detector starting...
Model is expected at flash address 0x400000.
Trigger threshold=0.75
Min box area=0.35
Required consecutive hits=1
Ready.
boxes=2
person score=0.842 x=0.2 y=0.1 w=0.6 h=0.8 area=0.48 target=0 usable=1
LIGHT ON
PERSON DETECTED best=0.842 raw=0.842 raw_area=0.48 valid=2 light=ON
perf preprocess=15ms inference=690ms postprocess=2ms
```

判讀：

| 輸出 | 意義 |
|---|---|
| `boxes=0` | 模型沒有輸出候選框 |
| `usable=0` | 有框但被面積過濾 |
| `usable=1` | 框大小合理，可用來判斷 |
| `PERSON DETECTED` | 判定有人 |
| `NO PERSON` | 判定沒有人 |
| `LIGHT ON` | 燈控輸出已打開 |
| `LIGHT OFF` | 超過 10 秒未偵測到人，燈控輸出已關閉 |
| 網頁紅框 | 通過門檻的 person 框 |
| 網頁黃框 | 被後處理過濾的小框 |

## 11. 調參方式

如果「有人但沒有反應」：

- 降低 `kTriggerThreshold`，例如 `0.75` 改 `0.65`。
- 降低 `kMinBoxArea`，例如 `0.35` 改 `0.25`。
- 降低 `score_threshold`，例如 `0.30` 改 `0.20`。

如果「沒人但常誤判」：

- 提高 `kTriggerThreshold`，例如 `0.75` 改 `0.80`。
- 提高 `kMinBoxArea`，例如 `0.35` 改 `0.45`。
- 保留 debug 輸出觀察 `raw_area` 與 `best`。

## 12. 問題與改進

遇到的主要問題：

1. 原始模型在空房間有時誤判。
2. 加入大量房間負樣本後，模型在實機上變得太保守。
3. int8 TFLite concat quantization scale 需要額外修正。
4. Arduino IDE 序列監控會佔用 COM port，燒錄前需關閉。

最後採用方案：

- 使用偵測能力較好的 `local_focus100` 模型。
- 不採用過度保守的 `local_bg_focus50` 模型。
- 用 Arduino 後處理的 `score + bbox area` 抑制假陽性。

未來改善方向：

- 增加更多實際使用角度的人像資料。
- 重新平衡 person 與 background 的比例，不讓負樣本壓過 person。
- 增加不同光線、距離、姿勢資料。
- 使用 validation set 以外的實機測試資料做 threshold tuning。
- 將 detection 結果接 LED、蜂鳴器或 MQTT。

## 13. YouTube 報告影片建議大綱

影片長度：8~10 分鐘。

建議段落：

1. 專題題目與目標，約 30 秒。
2. 硬體介紹：XIAO ESP32S3 Sense，約 1 分鐘。
3. 系統架構：camera、model、Arduino、serial output，約 1 分鐘。
4. 資料集與標註方式，約 1.5 分鐘。
5. 模型訓練與匯出流程，約 1.5 分鐘。
6. 燒錄流程與 GitHub 專案結構，約 1 分鐘。
7. 實機展示：沒人、有人的輸出，約 2 分鐘。
8. 遇到問題與改進，約 1 分鐘。

展示時務必錄到：

- Arduino IDE / Serial Monitor。
- 板子接 USB。
- 沒人時輸出 `NO PERSON`。
- 有人時輸出 `PERSON DETECTED`。
- GitHub README 或 HackMD 頁面。

## 14. 作業提交可貼連結

HackMD：

```text
請貼上本文件發布後的 HackMD 連結
```

GitHub：

```text
請貼上 edgeai-person-xiao-s3 repository 連結
```

YouTube：

```text
請貼上 8~10 分鐘影片連結
```
