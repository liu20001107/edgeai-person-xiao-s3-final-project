# XIAO ESP32S3 Person Detection

本專案是在 Seeed Studio XIAO ESP32S3 Sense 上執行的 Edge AI 人員偵測、智慧照明與即時影像顯示系統。模型會直接燒錄到 ESP32S3 flash，Arduino sketch 讀取相機影像後在板子端執行推論，不需要電腦或雲端推論。偵測到人時會打開板子內建 LED；最後一次偵測到人後維持亮燈 10 秒，10 秒內又偵測到人會重新計時。板子也會開啟 Wi-Fi AP，瀏覽器可看到 ESP32 拍到的畫面與偵測框。

## 專案內容

```text
edgeai-person-xiao-s3/
├─ arduino/
│  └─ sscma_person_arduino/
│     └─ sscma_person_arduino.ino
├─ models/
│  ├─ person_local_focus100_int8.tflite
│  └─ person_local_focus100_models_partition.bin
├─ scripts/
│  ├─ compile_upload_arduino.bat
│  ├─ flash_model.bat
│  └─ monitor.bat
├─ training/
│  ├─ sscma_person_grounding_dino_local_focus_train100_config.py
│  └─ sscma_person_grounding_dino_local_bg_focus_finetune50_config.py
└─ docs/
   └─ HackMD.md
```

## 給只有板子的使用者

如果板子已經燒好程式和模型，只需要：

1. 使用 USB-C 接上 XIAO ESP32S3 Sense。
2. 打開 Arduino IDE 的序列監控。
3. Baud rate 設為 `115200`。
4. 看到 `Ready.` 後即可測試。
5. 看板子上方內建 LED，偵測到人會亮，無人 10 秒後會熄滅。
6. 連上 Wi-Fi `XIAO-Person-Cam`，密碼 `12345678`。
7. 用瀏覽器開 `http://192.168.4.1`，可看到相機畫面與偵測框。

序列輸出：

- `PERSON DETECTED`：偵測到人。
- `NO PERSON`：目前沒有偵測到人。
- `LIGHT ON`：燈已打開。
- `LIGHT OFF`：超過 10 秒未偵測到人，燈已關閉。
- `person score=... area=... usable=...`：模型原始框與後處理資訊。

網頁畫面：

- 紅框：通過 score 與 area 條件的 person 框。
- 黃框：模型有輸出但被面積條件過濾掉的小框。
- 頁面上方會顯示 `PERSON DETECTED / NO PERSON`、best score、raw score、LED 狀態。

## 重新燒錄

### 1. 上傳 Arduino 程式

安裝 Arduino IDE 2.x、ESP32 board package、Seeed SSCMA Micro Core library 後執行：

```bat
scripts\compile_upload_arduino.bat COM3
```

如果連接埠不是 COM3，請改成實際連接埠。

### 2. 燒錄模型

需要已安裝 ESP-IDF 或可使用 `python -m esptool`：

```bat
scripts\flash_model.bat COM3
```

模型燒錄位置固定為：

```text
0x400000
```

### 3. 監看序列輸出

```bat
scripts\monitor.bat COM3
```

## 目前使用的模型

目前正式使用：

```text
models/person_local_focus100_models_partition.bin
```

這是 `local_focus100` 版本。它在實際相機畫面中較容易得到 `0.7~0.9` 的 person score。曾測試加入大量房間空景負樣本的 `local_bg_focus50` 版本，但在板子上分數被壓到約 `0.016~0.031`，太保守，因此正式版改回 `local_focus100`，並在 Arduino 端用 score 與 box area 過濾誤判。

## Arduino 判斷參數

目前設定在：

```cpp
static constexpr float kTriggerThreshold = 0.75f;
static constexpr float kMinBoxArea = 0.35f;
static constexpr uint32_t kLightHoldMs = 10000;
static constexpr int kLightPin = LED_BUILTIN;
static SSCMAMicroCore::InvokeConfig invoke_config = {
    .top_k = 10,
    .score_threshold = 0.30f,
    .nms_threshold = 0.45f,
};
```

調整方向：

- 容易漏偵測人：降低 `kTriggerThreshold` 或 `kMinBoxArea`。
- 沒人時容易誤判：提高 `kTriggerThreshold` 或 `kMinBoxArea`。
- 想看更多原始候選框：降低 `score_threshold`。
- 想讓燈維持更久：提高 `kLightHoldMs`，例如 30000 表示 30 秒。
- 要換成外接燈或繼電器：修改 `kLightPin`，例如改成 `D0`，並把 `kLightOnLevel` / `kLightOffLevel` 改成外接模組需要的電位。

## 智慧照明邏輯

燈控行為：

1. 偵測到人且分數與框面積通過門檻。
2. 立刻讓內建 LED 亮起。
3. 記錄最後一次偵測到人的時間。
4. 如果 10 秒內沒有再次偵測到人，內建 LED 熄滅。
5. 如果 10 秒內再次偵測到人，重新計時，燈保持亮。

本版本使用板子上方內建 LED，不需要外接電路。如果要改成控制真正燈具，建議改用外接繼電器模組，不要直接把 AC 電接板子。

## 即時影像與偵測框網頁

板子會開啟 Wi-Fi AP：

```text
SSID: XIAO-Person-Cam
Password: 12345678
URL: http://192.168.4.1
```

網頁功能：

1. `/`：主頁，顯示相機畫面與狀態。
2. `/jpg`：最新一張已畫框的 JPEG。
3. `/status`：JSON 格式偵測狀態。

實作方式：

- 每次推論後，把 RGB565 frame 複製一份。
- 將模型輸出的 bbox 畫到影像上。
- 使用 `fmt2jpg()` 轉成 JPEG。
- 瀏覽器定時刷新 `/jpg` 與 `/status`。

因為模型推論約 0.7 秒一次，所以網頁更新速度約 1 FPS，適合展示與智慧居家狀態監控。

## 訓練摘要

主要流程：

1. 收集 person 與實際房間相機畫面。
2. 使用 GroundingDINO 輔助標註 person bbox。
3. 整理成 COCO dataset。
4. 使用 Seeed ModelAssistant / SSCMA 訓練 YOLOv5 tiny person detector。
5. 匯出 int8 TFLite。
6. 修正 TFLite concat quantization scale。
7. 包成 4MB model partition。
8. 燒錄到 ESP32S3 `0x400000`。
9. Arduino sketch 執行攝影機擷取與板端推論。

完整報告文字請看 [docs/HackMD.md](docs/HackMD.md)。
