#include <Arduino.h>
#include <SSCMA_Micro_Core.h>
#include <esp_camera.h>
#include <img_converters.h>
#include <math.h>
#include <vector>

SET_LOOP_TASK_STACK_SIZE(40 * 1024);

SSCMAMicroCore ai;
SSCMAMicroCore::VideoCapture camera;

static constexpr float kTriggerThreshold = 0.75f;
static constexpr float kMinBoxArea = 0.35f;
static constexpr uint32_t kDetectHoldMs = 800;
static constexpr uint8_t kRequiredHits = 1;
static constexpr uint32_t kLightHoldMs = 10000;
static constexpr int kLightPin = LED_BUILTIN;
static constexpr uint8_t kLightOnLevel = LOW;
static constexpr uint8_t kLightOffLevel = HIGH;
static constexpr uint32_t kSerialBaud = 921600;
static constexpr bool kVerboseSerialText = false;
static uint32_t last_detect_ms = 0;
static uint32_t last_light_detect_ms = 0;
static uint8_t consecutive_hits = 0;
static bool light_is_on = false;
static float latest_best_score = 0.0f;
static float latest_raw_best_score = 0.0f;
static float latest_raw_best_area = 0.0f;
static int latest_valid_count = 0;
static bool latest_detected = false;
static std::vector<uint8_t> latest_jpg;
static const uint8_t kFrameMagic[] = {'X', 'I', 'A', 'O', 'A', 'I', '1', '\n'};

static SSCMAMicroCore::InvokeConfig invoke_config = {
    .top_k = 10,
    .score_threshold = 0.30f,
    .nms_threshold = 0.45f,
};

static SSCMAMicroCore::Config ai_config = {
    .model_id = 0,
    .algorithm_id = 0,
    .invoke_config = &invoke_config,
};

void printResult(const SSCMAMicroCore::Box& box) {
    Serial.printf(
        "person score=%.3f x=%.1f y=%.1f w=%.1f h=%.1f area=%.2f target=%d usable=%d\n",
        box.score,
        box.x,
        box.y,
        box.w,
        box.h,
        box.w * box.h,
        box.target,
        isUsablePersonBox(box) ? 1 : 0
    );
}

bool isValidBox(const SSCMAMicroCore::Box& box) {
    return isfinite(box.score) && isfinite(box.x) && isfinite(box.y) && isfinite(box.w) && isfinite(box.h);
}

bool isUsablePersonBox(const SSCMAMicroCore::Box& box) {
    if (!isValidBox(box)) {
        return false;
    }
    const float area = box.w * box.h;
    return area >= kMinBoxArea;
}

void setLight(bool on) {
    if (light_is_on == on) {
        return;
    }
    light_is_on = on;
    digitalWrite(kLightPin, on ? kLightOnLevel : kLightOffLevel);
    if (kVerboseSerialText) {
        Serial.printf("LIGHT %s\n", on ? "ON" : "OFF");
    }
}

uint16_t rgb565(uint8_t r, uint8_t g, uint8_t b) {
    return ((r & 0xF8) << 8) | ((g & 0xF8) << 3) | (b >> 3);
}

void setPixelRgb565(std::vector<uint8_t>& image, int width, int height, int x, int y, uint16_t color) {
    if (x < 0 || y < 0 || x >= width || y >= height) {
        return;
    }
    const size_t offset = (static_cast<size_t>(y) * width + x) * 2;
    image[offset] = color & 0xFF;
    image[offset + 1] = color >> 8;
}

void drawRectRgb565(std::vector<uint8_t>& image, int width, int height, const SSCMAMicroCore::Box& box, uint16_t color) {
    int x0 = static_cast<int>((box.x - box.w * 0.5f) * width);
    int y0 = static_cast<int>((box.y - box.h * 0.5f) * height);
    int x1 = static_cast<int>((box.x + box.w * 0.5f) * width);
    int y1 = static_cast<int>((box.y + box.h * 0.5f) * height);
    x0 = constrain(x0, 0, width - 1);
    y0 = constrain(y0, 0, height - 1);
    x1 = constrain(x1, 0, width - 1);
    y1 = constrain(y1, 0, height - 1);
    for (int t = 0; t < 3; ++t) {
        for (int x = x0; x <= x1; ++x) {
            setPixelRgb565(image, width, height, x, y0 + t, color);
            setPixelRgb565(image, width, height, x, y1 - t, color);
        }
        for (int y = y0; y <= y1; ++y) {
            setPixelRgb565(image, width, height, x0 + t, y, color);
            setPixelRgb565(image, width, height, x1 - t, y, color);
        }
    }
}

void updateLatestJpeg(const std::shared_ptr<SSCMAMicroCore::Frame>& frame, const std::vector<SSCMAMicroCore::Box>& boxes) {
    if (!frame || frame->format != SSCMAMicroCore::kRGB565 || frame->data == nullptr || frame->size == 0) {
        return;
    }
    std::vector<uint8_t> rgb(frame->data, frame->data + frame->size);
    const uint16_t red = rgb565(255, 0, 0);
    const uint16_t yellow = rgb565(255, 220, 0);
    for (const auto& box : boxes) {
        if (!isValidBox(box)) {
            continue;
        }
        drawRectRgb565(rgb, frame->width, frame->height, box, isUsablePersonBox(box) ? red : yellow);
    }

    uint8_t* jpg_buf = nullptr;
    size_t jpg_len = 0;
    if (fmt2jpg(rgb.data(), rgb.size(), frame->width, frame->height, PIXFORMAT_RGB565, 80, &jpg_buf, &jpg_len)) {
        latest_jpg.assign(jpg_buf, jpg_buf + jpg_len);
        free(jpg_buf);
    }
}

void writeU32LE(uint32_t value) {
    Serial.write(static_cast<uint8_t>(value & 0xFF));
    Serial.write(static_cast<uint8_t>((value >> 8) & 0xFF));
    Serial.write(static_cast<uint8_t>((value >> 16) & 0xFF));
    Serial.write(static_cast<uint8_t>((value >> 24) & 0xFF));
}

String buildStatusJson(const std::vector<SSCMAMicroCore::Box>& boxes) {
    String json = "{";
    json += "\"detected\":" + String(latest_detected ? "true" : "false") + ",";
    json += "\"best\":" + String(latest_best_score, 3) + ",";
    json += "\"raw\":" + String(latest_raw_best_score, 3) + ",";
    json += "\"raw_area\":" + String(latest_raw_best_area, 3) + ",";
    json += "\"valid\":" + String(latest_valid_count) + ",";
    json += "\"light\":\"" + String(light_is_on ? "ON" : "OFF") + "\",";
    json += "\"threshold\":" + String(kTriggerThreshold, 3) + ",";
    json += "\"min_area\":" + String(kMinBoxArea, 3) + ",";
    json += "\"boxes\":[";
    bool first = true;
    for (const auto& box : boxes) {
        if (!isValidBox(box)) {
            continue;
        }
        if (!first) {
            json += ",";
        }
        first = false;
        json += "{";
        json += "\"score\":" + String(box.score, 3) + ",";
        json += "\"x\":" + String(box.x, 3) + ",";
        json += "\"y\":" + String(box.y, 3) + ",";
        json += "\"w\":" + String(box.w, 3) + ",";
        json += "\"h\":" + String(box.h, 3) + ",";
        json += "\"area\":" + String(box.w * box.h, 3) + ",";
        json += "\"usable\":" + String(isUsablePersonBox(box) ? "true" : "false");
        json += "}";
    }
    json += "]";
    json += "}";
    return json;
}

void sendSerialFrame(const std::vector<SSCMAMicroCore::Box>& boxes) {
    if (latest_jpg.empty()) {
        return;
    }
    const String json = buildStatusJson(boxes);
    Serial.write(kFrameMagic, sizeof(kFrameMagic));
    writeU32LE(static_cast<uint32_t>(json.length()));
    writeU32LE(static_cast<uint32_t>(latest_jpg.size()));
    Serial.write(reinterpret_cast<const uint8_t*>(json.c_str()), json.length());
    Serial.write(latest_jpg.data(), latest_jpg.size());
}

void setup() {
    Serial.begin(kSerialBaud);
    delay(1500);

    Serial.println();
    Serial.println("SSCMA person detector starting...");
    Serial.println("Model is expected at flash address 0x400000.");
    Serial.printf("USB serial frame stream baud=%u\n", kSerialBaud);
    Serial.printf("Trigger threshold=%.2f\n", kTriggerThreshold);
    Serial.printf("Min box area=%.2f\n", kMinBoxArea);
    Serial.printf("Required consecutive hits=%u\n", kRequiredHits);
    Serial.printf("Light pin=LED_BUILTIN(GPIO%d) hold=%ums\n", kLightPin, kLightHoldMs);
    pinMode(kLightPin, OUTPUT);
    digitalWrite(kLightPin, kLightOffLevel);

    auto ret = camera.begin(SSCMAMicroCore::VideoCapture::DefaultCameraConfigXIAOS3);
    if (!ret.success) {
        Serial.print("Camera init failed: ");
        Serial.println(ret.message.c_str());
        while (true) delay(1000);
    }

    ret = ai.begin(ai_config);
    if (!ret.success) {
        Serial.print("AI init failed: ");
        Serial.println(ret.message.c_str());
        Serial.println("If this says model/load failed, re-flash xiao_person_grounding_dino_clean100_int8_patched_models_partition.bin to 0x400000.");
        while (true) delay(1000);
    }

    Serial.println("Ready. Open VS Code viewer, not Arduino Serial Monitor.");
}

void loop() {
    auto frame = camera.getManagedFrame();
    if (!frame) {
        if (kVerboseSerialText) {
            Serial.println("Camera frame failed");
        }
        delay(250);
        return;
    }

    auto ret = ai.invoke(frame, &invoke_config);
    if (!ret.success) {
        if (kVerboseSerialText) {
            Serial.print("Invoke failed: ");
            Serial.println(ret.message.c_str());
        }
        delay(1000);
        return;
    }

    const auto& boxes = ai.getBoxes();
    if (kVerboseSerialText) {
        Serial.printf("boxes=%u\n", static_cast<unsigned>(boxes.size()));
    }
    int valid_count = 0;
    float best_score = 0.0f;
    float raw_best_score = 0.0f;
    float raw_best_area = 0.0f;
    for (const auto& box : boxes) {
        if (!isValidBox(box)) {
            continue;
        }
        ++valid_count;
        const float area = box.w * box.h;
        if (box.score > raw_best_score) {
            raw_best_score = box.score;
            raw_best_area = area;
        }
        if (isUsablePersonBox(box) && box.score > best_score) {
            best_score = box.score;
        }
        if (kVerboseSerialText) {
            printResult(box);
        }
    }

    if (best_score >= kTriggerThreshold) {
        if (consecutive_hits < kRequiredHits) {
            ++consecutive_hits;
        }
    } else {
        consecutive_hits = 0;
    }

    if (consecutive_hits >= kRequiredHits) {
        last_detect_ms = millis();
        last_light_detect_ms = millis();
    }

    const bool detected = (millis() - last_detect_ms) <= kDetectHoldMs;
    const bool light_should_on = (millis() - last_light_detect_ms) <= kLightHoldMs;
    setLight(light_should_on);
    latest_best_score = best_score;
    latest_raw_best_score = raw_best_score;
    latest_raw_best_area = raw_best_area;
    latest_valid_count = valid_count;
    latest_detected = detected;
    updateLatestJpeg(frame, boxes);
    sendSerialFrame(boxes);

    if (kVerboseSerialText) {
        if (detected) {
            Serial.printf("PERSON DETECTED best=%.3f raw=%.3f raw_area=%.2f valid=%d light=%s\n",
                          best_score, raw_best_score, raw_best_area, valid_count,
                          light_is_on ? "ON" : "OFF");
        } else {
            Serial.printf("NO PERSON best=%.3f raw=%.3f raw_area=%.2f valid=%d light=%s\n",
                          best_score, raw_best_score, raw_best_area, valid_count,
                          light_is_on ? "ON" : "OFF");
        }

        const auto& perf = ai.getPerf();
        Serial.printf(
            "perf preprocess=%ums inference=%ums postprocess=%ums\n",
            perf.preprocess,
            perf.inference,
            perf.postprocess
        );
    }

    delay(250);
}
