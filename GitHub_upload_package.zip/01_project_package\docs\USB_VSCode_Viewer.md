# USB VS Code Viewer

這一版不用 Wi-Fi。XIAO ESP32S3 Sense 會透過 USB Serial 把「相機 JPEG 畫面 + 偵測狀態」傳到電腦，電腦用 VS Code 跑 Python 視窗顯示。

## 使用方式

1. 先把 Arduino Serial Monitor 關掉，因為 COM port 同一時間只能給一個程式使用。
2. 用 USB-C 連接 XIAO ESP32S3 Sense。
3. 開 VS Code，打開這個專案資料夾。
4. 在 VS Code Terminal 執行：

```bat
py -m pip install pyserial pillow
py pc_viewer\serial_person_viewer.py COM3
```

如果你的板子不是 COM3，把最後一行改成你的連接埠，例如：

```bat
py pc_viewer\serial_person_viewer.py COM5
```

## 顯示內容

- 畫面：ESP32 相機即時拍到的 JPEG。
- 紅框：通過面積篩選的 person box。
- 黃框：模型有輸出，但面積太小，被程式過濾掉。
- `PERSON DETECTED`：分數與框大小都通過，板子 LED 會亮。
- `NO PERSON`：沒有通過條件的人，LED 會在 10 秒後關掉。

## 目前板子端設定

```cpp
static constexpr float kTriggerThreshold = 0.75f;
static constexpr float kMinBoxArea = 0.35f;
static constexpr uint32_t kLightHoldMs = 10000;
static constexpr uint32_t kSerialBaud = 921600;
```

調整方式：

- 太容易誤判：提高 `kTriggerThreshold` 或 `kMinBoxArea`。
- 太不容易亮燈：降低 `kTriggerThreshold` 或 `kMinBoxArea`。
- 想讓燈亮更久：提高 `kLightHoldMs`，例如 `30000` 是 30 秒。

## 注意

這個 viewer 用的是 USB，不需要連 ESP32 的 Wi-Fi，也不需要手機瀏覽器。畫面 FPS 會受模型推論時間影響，目前每次推論大約 0.7 秒左右。
